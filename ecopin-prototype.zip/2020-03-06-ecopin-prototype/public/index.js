const map = L.map("map").setView([51.505, -0.09], 13);

L.tileLayer(
  "https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}",
  {
    attribution:
      'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: "mapbox/streets-v11",
    tileSize: 512,
    zoomOffset: -1,
    accessToken:
      "pk.eyJ1IjoiZXZhbm1oYWhuIiwiYSI6ImNrN2dyZGE5cTAycDQzZnFrbmc4YXg4NnQifQ.HPgR0vHCjTCqWDM0jSFDNQ"
  }
).addTo(map);

const icons = ["red", "green", "blue"].reduce(
  (result, color) => ({
    ...result,
    [color]: new L.Icon({
      iconUrl: `vendor/marker-icon-2x-${color}.png`,
      shadowUrl: "vendor/marker-shadow.png",
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41]
    })
  }),
  {}
);

L.marker([51.5, -0.09], { icon: icons.green })
  .bindPopup("Good place")
  .addTo(map);

L.marker([51.51, -0.09], { icon: icons.blue })
  .bindPopup("Protest area")
  .addTo(map);

L.marker([51.49, -0.08], { icon: icons.red })
  .bindPopup("Big polluter")
  .addTo(map);
